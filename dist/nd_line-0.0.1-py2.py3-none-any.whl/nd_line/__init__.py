#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    __init__.py
    ~~~~~~~~~~~

    no description available

    :copyright: (c) 2021 by dpm42.
    :license: see LICENSE for more details.
"""

__title__ = 'nd_line'
__version__ = '0.0.1'
__author__ = 'dpm42'
